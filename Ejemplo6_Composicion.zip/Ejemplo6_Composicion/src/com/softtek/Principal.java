package com.softtek;

import com.softtek.models.Direccion;
import com.softtek.models.Empleado;

public class Principal {

	public static void main(String[] args) {
		
		Direccion dir1 = new Direccion("Mayor", 5, "Madrid");
		Empleado empleado1 = new Empleado("Alfredo", 42, 54_000, dir1);
		empleado1.mostrar();
		
		Empleado empleado2 = new Empleado("Marta", 48, 63_000, 
				new Direccion("Diagonal", 184, "Barcelona"));
		empleado2.mostrar();
		
		Empleado empleado3 = new Empleado();
		empleado3.setNombre("Federico");
		empleado3.setEdad(32);
		empleado3.setSueldo(42_000);
		empleado3.setDireccion(new Direccion());
		empleado3.getDireccion().setCalle("Real");
		empleado3.getDireccion().setNumero(63);
		empleado3.getDireccion().setPoblacion("Toledo");
		empleado3.mostrar();

	}

}
