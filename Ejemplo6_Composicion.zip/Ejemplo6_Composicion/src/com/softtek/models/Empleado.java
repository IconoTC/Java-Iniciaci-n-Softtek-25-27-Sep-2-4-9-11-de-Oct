package com.softtek.models;

public class Empleado {
	
	private String nombre;
	private int edad;
	private double sueldo;
	private Direccion direccion;
	
	public Empleado() {
		// TODO Auto-generated constructor stub
	}

	public Empleado(String nombre, int edad, double sueldo, Direccion direccion) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.sueldo = sueldo;
		this.direccion = direccion;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	public Direccion getDireccion() {
		return direccion;
	}

	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}
	
	public void mostrar() {
		System.out.println("Nombre: " + nombre + " Edad: " + edad + 
				" Sueldo: " + sueldo + " Direccion: " + direccion.mostrar());
	}

}
