package com.softtek;

import com.softtek.business.TaskManager;
import com.softtek.models.Task;

public class TaskManagerTest {

	public static void main(String[] args) {
		
		// Crear una instancia de TaskManager
		TaskManager taskManager = new TaskManager();
		
		// Crear una instancia de Task, utilizando TaskManager
		// Verificar que esta STARTED
		Task task = taskManager.create("Anabel");
		System.out.println(task.getState());
		
		// Asignarla (assign) a un usuario.
		// Verificar que esta PENDING
		taskManager.assign(task, "Pedro");
		System.out.println(task.getState());
		
		// Ejecutarla (perform)
		// Verificar que esta PERFORMED
		taskManager.perform(task);
		System.out.println(task.getState());
		
		// Revisarla (review), no aceptando el resultado.
		// Verificar que vuelve a estar PENDING
		taskManager.review(task, false);
		System.out.println(task.getState());
		
		// Volver a ejecutarla (perform)
		// Verificar que esta PERFORMED
		taskManager.perform(task);
		System.out.println(task.getState());
		
		// Volver a revisarla (review), aceptando esta vez el resultado.
		// Verificar que vuelve a estar COMPLETED
		taskManager.review(task, true);
		System.out.println(task.getState());
		

	}

}
