package com.softtek.util;

import com.softtek.models.Producto;

public class Utilidad {
	
	public void comprobar(Producto producto) {
		
		assert producto.getPrecio() > 0 : "El precio no puede igual o inferior a 0";
		
	}

}
