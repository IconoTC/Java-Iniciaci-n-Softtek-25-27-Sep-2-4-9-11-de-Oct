package com.softtek;

import com.softtek.models.Producto;
import com.softtek.util.Utilidad;

public class AppMain {

	public static void main(String[] args) {
		
		Utilidad util = new Utilidad();
		
		Producto p1 = new Producto(1, "Producto 1", 39);
		util.comprobar(p1);
		Producto p2 = new Producto(2, "Producto 2", -43);
		util.comprobar(p2);
		Producto p3 = new Producto(3, "Producto 3", 0);
		util.comprobar(p3);
	}

}
