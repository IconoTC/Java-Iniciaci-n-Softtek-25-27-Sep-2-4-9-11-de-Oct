package com.softtek.models;

public class Cliente {
	
	// Propiedades, atributos, campos
	// Variables globales
	// Caracteristicas que necesito de un cliente
	
	// acceso tipo nombre = valor_inicial;
	public String nombre;
	public String nif;
	public char sexo;
	public int edad;
	public boolean vip;
	
	
	// El compilador, en el momento de la compilacion, si ve
	// que no hay declarado ningun constructor, añade el constructor por defecto
	// si ya hay un constructor, no agrega nada
	public Cliente() {
		// TODO Auto-generated constructor stub
	}
	
	// Constructor completo
	public Cliente(String nombre, String nif, char sexo, int edad, boolean vip) {
		super();
		this.nombre = nombre;
		this.nif = nif;
		this.sexo = sexo;
		this.edad = edad;
		this.vip = vip;
	}


	// Metodos, funciones, acciones
	
	// acceso tipo_retorno|void nombre(){}
	public void cambiarVip(boolean valor) {
		vip = valor;
	}
	
	public int verEdad() {
		return edad;
	}
	
	public void mostrarInfo() {
		System.out.println("Nombre: " + nombre + " Nif: " + nif + 
				" Sexo: " + sexo + " Edad: " + edad + " Vip: " + vip);
	}

}
