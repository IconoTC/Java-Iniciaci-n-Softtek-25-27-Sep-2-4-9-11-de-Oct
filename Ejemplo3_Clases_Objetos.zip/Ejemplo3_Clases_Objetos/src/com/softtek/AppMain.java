package com.softtek;

// Toda clase que este en otro paquete hay que importarla
import com.softtek.models.Cliente;

public class AppMain {

	public static void main(String[] args) {
		
		int numero = 63;
		String nombre = "Juan";
		
		// Crear un objeto o instancia de la clase Cliente
		Cliente cliente1 = new Cliente();

		// Asignar valores al objeto
		cliente1.nombre = "Juan";
		cliente1.nif = "12345678-A";
		cliente1.sexo = 'H';
		cliente1.edad = 48;
		cliente1.vip = true;
		
		// Acceder a los metodos
		cliente1.mostrarInfo();
		cliente1.cambiarVip(false);
		cliente1.mostrarInfo();
		System.out.println("Edad: " + cliente1.verEdad());
		
		
		// Crear un objeto invocando al constructor completo
		Cliente cliente2 = new Cliente("Maria", "98765432-B", 'M', 35, false);
		cliente2.mostrarInfo();
	}

}
