package com.softtek;

public class Numeros1_10 {

	public static void main(String[] args) {
		
		// Mostrar los numeros del 1 al 10
		for(int num=1; num <= 10; num++) {
			System.out.println(num);
		}
		System.out.println("------------ FIN ------------");

		
		// Mostrar los numeros del 10 al 1
		for(int num = 10; num >= 1; num--) {
			System.out.println(num);
		}
		System.out.println("------------ FIN ------------");
	
		
		// Mostrar los numeros del 0 al 10 de 2 en 2
		for(int num=0; num <= 10; num += 2) {   // num = num + 2
			System.out.println(num);
		}
		System.out.println("------------ FIN ------------");
	
		
		// Mostrar los numeros del 1 al 50 pero solo los multiplos de 5
		for(int num=1; num <= 50; num++) {
			if (num % 5 == 0)
				System.out.println(num);
		}
		System.out.println("------------ FIN ------------");
	}

}
