package com.softtek;

public class TablasMultiplicar {

	public static void main(String[] args) {
		
		// Mostrar las tablas de multiplicar del 1 al 10
		for(int tabla=1; tabla <= 10; tabla++) {
			System.out.println("------- Tabla del " + tabla + "-------");
			
			for(int num=1; num <= 10; num++) {
				System.out.println(tabla + " x " + num + " = " + (tabla*num));
			}
			System.out.println();
		}
	}

}
