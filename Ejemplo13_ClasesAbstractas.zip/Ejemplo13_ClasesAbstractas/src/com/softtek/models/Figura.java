package com.softtek.models;

// Cuando una clase tiene un metodo abstracto, la clase se debe declarar como abstracta
public abstract class Figura {
	
	private double coordenadaX;
	private double coordenadaY;
	
	public Figura() {
		// TODO Auto-generated constructor stub
	}

	public Figura(double coordenadaX, double coordenadaY) {
		super();
		this.coordenadaX = coordenadaX;
		this.coordenadaY = coordenadaY;
	}
	
	// Metodo declarado pero no implementado
	public abstract double calcularArea();

	public double getCoordenadaX() {
		return coordenadaX;
	}

	public void setCoordenadaX(double coordenadaX) {
		this.coordenadaX = coordenadaX;
	}

	public double getCoordenadaY() {
		return coordenadaY;
	}

	public void setCoordenadaY(double coordenadaY) {
		this.coordenadaY = coordenadaY;
	}

	@Override
	public String toString() {
		return "[" + coordenadaX + "," + coordenadaY + "]";
	}
	
	

}
