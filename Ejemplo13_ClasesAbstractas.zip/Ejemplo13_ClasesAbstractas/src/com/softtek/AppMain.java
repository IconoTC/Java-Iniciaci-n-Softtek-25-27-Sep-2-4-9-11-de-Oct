package com.softtek;

import com.softtek.models.Circulo;
import com.softtek.models.Figura;
import com.softtek.models.Rectangulo;

public class AppMain {

	public static void main(String[] args) {
		
		Rectangulo rectangulo = new Rectangulo(10, 20, 27.95, 14.38);
		System.out.println("Area del rectangulo: " + rectangulo.calcularArea());
		System.out.println(rectangulo);
		
		Circulo circulo = new Circulo(10, 20, 18.25);
		System.out.println("Area del circulo: " + circulo.calcularArea());
		System.out.println(circulo);
		
		// Las clases abstractas pueden ser tipo de dato
		// pero no se pueden instanciar
		//Figura figura = new Figura();
		
		// Si me deja instanciar Figura si en el mismo momento
		// implemento el metodo abstracto
		Figura triangulo =  new Figura(10, 20) {
			
			private double base = 27.95;
			private double altura = 14.38;
			
			@Override
			public double calcularArea() {
				// TODO Auto-generated method stub
				return base * altura / 2;
			}
		};
		System.out.println("Area del triangulo: " + triangulo.calcularArea());
		System.out.println(triangulo);

	}

}
