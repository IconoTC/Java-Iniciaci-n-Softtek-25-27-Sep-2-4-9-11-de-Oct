package com.softtek;

import java.util.Arrays;

public class DosDimensiones {

	public static void main(String[] args) {
		
		// Declarar un array de 2 dimensiones
		int numeros[][];
		
		// Crear el array
		numeros = new int[3][2];    // 3 filas x 2 columnas
		
		// Asignar valores al array
		numeros[0][0] = 7;    // array[fila][columna]
		numeros[0][1] = 2;
		numeros[1][0] = 9;
		numeros[1][1] = 4;
		numeros[2][0] = 1;
		numeros[2][1] = 6;
		
		// Todo en uno
		int numeros2[][] = { {7,2}, {9,4}, {1,6} };
		int numeros3[][] = new int[][]{ {7,2}, {9,4}, {1,6} };
		
		// Matriz no cuadrada
		int numeros4[][] = new int[3][];   // 3 filas
		numeros4[0] = new int[2];
		numeros4[1] = new int[4];
		numeros4[2] = new int[3];
		
		// Asignar valores
		numeros4[0][0] = 1;
		numeros4[0][1] = 9;
		numeros4[1][0] = 3;
		numeros4[1][1] = 4;
		numeros4[1][2] = 7;
		numeros4[1][3] = 2;
		numeros4[2][0] = 5;
		numeros4[2][1] = 8;
		numeros4[2][2] = 6;
		
		// Todo en uno
		int numeros5[][] = { {1,9}, {3,4,7,2}, {5,8,6} };
		
		
		// Recorrer con for tradicional
		for(int fila=0; fila < numeros4.length; fila++) {
			for(int col=0; col<numeros4[fila].length; col++) {
				System.out.print(numeros4[fila][col] + "\t");
			}
			System.out.println();
		}
		
		// Recorrer con for-each
		for (int[] fila : numeros5) {
			for (int num : fila) {
				System.out.print(num + "\t");
			}
			System.out.println();
		}
		
		System.out.println(numeros5);
		System.out.println(Arrays.deepToString(numeros5));
		
	}

}
