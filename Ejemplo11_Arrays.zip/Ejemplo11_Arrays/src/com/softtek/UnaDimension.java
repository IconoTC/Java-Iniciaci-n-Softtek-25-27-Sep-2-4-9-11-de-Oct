package com.softtek;

import java.util.Arrays;

public class UnaDimension {

	public static void main(String[] args) {
		
		// Declarar una variable de tipo array
		int numeros[];
		
		// Crear un array para 5 numeros
		numeros = new int[5];  // 5 es la longitud del array (length)
		
		// Asignar valores al array
		numeros[0] = 6;
		numeros[1] = 3;
		numeros[2] = 8;
		numeros[3] = 2;
		numeros[4] = 7;   // indice esta entre 0 y longitud-1
		
		// Todo en uno
		int[] numeros2 = {6,3,8,2,7};
		int [] numeros3 = new int[]{6,3,8,2,7};
		
		// Recorrido con el bucle for
		for(int idx=0; idx < numeros.length; idx++) {
			System.out.println(numeros[idx]);
		}
		
		// Recorrido con el bucle for-each
		for(int item : numeros) {
			System.out.println(item);
		}
		
		// En Java, los arrays no son redimensionales
		// solucion: crear un array mas grande y volcar los datos
		int grande[] = new int[10];
		System.arraycopy(numeros, 0, grande, 0, numeros.length);
		
		System.out.println(grande);
		System.out.println(Arrays.toString(grande));

	}

}
