package com.softtek;

public class AppMain {

	public static void main(String[] args) {
		
		ItfzCalculadora suma = (double n1, double n2) -> {
			return n1 + n2;
		};
		
		System.out.println(suma.operacion(7, 3));
		
		ItfzCalculadora resta = (double n1, double n2) -> 
			n1 - n2;
		
		System.out.println(resta.operacion(7, 3));
		
		ItfzCalculadora multiplicacion = (n1, n2) -> 
			n1 * n2;
		
		System.out.println(multiplicacion.operacion(7, 3));
		
		ItfzCalculadora division = (n1, n2) -> {
			return n1 / n2;
		};
		
		System.out.println(division.operacion(7, 3));

	}

}
