package com.softtek;

import java.util.Scanner;

public class EstadoCivil {

	public static void main(String[] args) {
		// solicitar letra al usuario para adivinar su estado civil
		// puede ser mayuscula o minuscula s o S
		// soltero, casado, viudo, divorciado, pareja_hecho
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce estado civil (S,C,V,D,P): ");
		char estado = sc.next().charAt(0);
		
		if (estado == 's' || estado == 'S') {
			System.out.println("Soltero");
		} else if (estado == 'c' || estado == 'C') {
			System.out.println("Casado");
		} else if (estado == 'v' || estado == 'V') {
			System.out.println("Viudo");
		} else if (estado == 'd' || estado == 'D') {
			System.out.println("Divorciado");
		} else if (estado == 'p' || estado == 'P') {
			System.out.println("Pareja de hecho");
		} else {
			System.out.println("Estado civil desconocido");
		}

	}

}
