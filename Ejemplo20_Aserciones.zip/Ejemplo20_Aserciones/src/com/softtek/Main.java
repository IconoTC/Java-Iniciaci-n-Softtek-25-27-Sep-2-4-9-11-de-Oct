package com.softtek;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce edad: ");
		int edad = sc.nextInt();
		
		// Por defecto, las aserciones estan deshabilitadas
		// Proyecto / boton dcho / Run As ... / Run Configurations / Pestaña arguments / VM arguments
		// ponemos -ea (Enabled Assertions)
		if (edad >= 18) {
			System.out.println("Eres mayor de edad");
		} else {
			assert (edad >= 0) : "La edad no puede ser negativa";
			System.out.println("Eres menor de edad");
		} 

	}

}
