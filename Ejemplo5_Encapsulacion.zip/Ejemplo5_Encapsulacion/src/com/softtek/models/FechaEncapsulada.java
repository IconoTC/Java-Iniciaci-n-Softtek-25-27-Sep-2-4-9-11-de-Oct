package com.softtek.models;

// Una clase encapsulada, define todas sus propiedades como privadas
// y se accede a ellas a través, de metodos get y set publicos
public class FechaEncapsulada {

	private int dia;
	private int mes;
	private int anyo;

	// Metodo de lectura
	public int getDia() {
		return dia;
	}

	// Metodo de escritura
	public void setDia(int dia) {
		if (dia >= 1 && dia <= 31) {
			this.dia = dia;
		} else {
			System.out.println("Dia no valido");
		}
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		if (mes >= 1 && mes <= 12) {
			this.mes = mes;
		} else {
			System.out.println("Mes no valido");
		}
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		if (anyo == 2023 || anyo == 2024) {
			this.anyo = anyo;
		} else {
			System.out.println("Año no valido");
		}		
	}

	public void mostrar() {
		System.out.println(dia + "/" + mes + "/" + anyo);
	}

}
