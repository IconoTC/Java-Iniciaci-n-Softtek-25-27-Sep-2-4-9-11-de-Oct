package com.softtek;

import com.softtek.models.Fecha;
import com.softtek.models.FechaEncapsulada;

public class Main {

	public static void main(String[] args) {
		
		Fecha fecha = new Fecha();
		fecha.dia = 25;
		fecha.mes = 9;
		fecha.anyo = 2023;
		
		fecha.mostrar();
		
		
		Fecha fechaErronea = new Fecha();
		fechaErronea.dia = 7654;
		fechaErronea.mes = 23455;
		fechaErronea.anyo = -23;
		
		fechaErronea.mostrar();
		
		
		FechaEncapsulada fechaEncapsulada = new FechaEncapsulada();
		fechaEncapsulada.setDia(7654);
		fechaEncapsulada.setMes(23455);
		fechaEncapsulada.setAnyo(-23);
		
		fechaEncapsulada.mostrar();
		
		
		// Probar con una fecha coherente
		FechaEncapsulada hoy = new FechaEncapsulada();
		hoy.setDia(25);
		hoy.setMes(9);
		hoy.setAnyo(2023);
		
		hoy.mostrar();

	}

}
