package com.softtek.utils;

import java.util.Comparator;

import com.softtek.models.Alumno;

public class NotaComparator implements Comparator<Alumno> {

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		// 1 o numero positivo si la instancia es mayor que el objeto recibido
		// -1 o numero negativo si la instancia es menor que el objeto recibido
		// 0 si son iguales

		// Queremos clasificar los alumnos por nota
		if (alum1.getNotaMedia() > alum2.getNotaMedia()) {
			return 1;
		} else if (alum1.getNotaMedia() < alum2.getNotaMedia()) {
			return -1;
		} else {
			// ordenar por nombre
			return alum1.getNombre().compareTo(alum2.getNombre());
		}
	}

}
