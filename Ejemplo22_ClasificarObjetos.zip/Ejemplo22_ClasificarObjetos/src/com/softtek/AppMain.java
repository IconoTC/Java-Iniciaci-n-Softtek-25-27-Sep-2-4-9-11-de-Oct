package com.softtek;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import com.softtek.models.Alumno;
import com.softtek.models.AlumnoComparable;
import com.softtek.utils.ApellidoComparator;
import com.softtek.utils.NotaComparator;

public class AppMain {

	public static void main(String[] args) {
		
		// Para tener los objetos clasificados se utilizan arboles
		Set<AlumnoComparable> alumnosNota = new TreeSet<AlumnoComparable>();
		alumnosNota.add(new AlumnoComparable(1, "Juan", "Perez", 7.3));
		alumnosNota.add(new AlumnoComparable(2, "Pedro", "Arias", 4.8));
		alumnosNota.add(new AlumnoComparable(3, "Maria", "Rodriguez", 6.9));
		alumnosNota.add(new AlumnoComparable(4, "Luis", "Sanchez", 5.6));
		alumnosNota.add(new AlumnoComparable(5, "Laura", "Gomez", 7.3));
		alumnosNota.add(new AlumnoComparable(6, "Antonio", "Lara", 8.2));
		
		for (AlumnoComparable alumno : alumnosNota) {
			System.out.println(alumno);
		}
		System.out.println("-------------------");
		
		Comparator<Alumno> comparadorNota = new NotaComparator();
		
		Set<Alumno> alumnos = new TreeSet<Alumno>(comparadorNota);
		alumnos.add(new Alumno(1, "Juan", "Perez", 7.3));
		alumnos.add(new Alumno(2, "Pedro", "Arias", 4.8));
		alumnos.add(new Alumno(3, "Maria", "Rodriguez", 6.9));
		alumnos.add(new Alumno(4, "Luis", "Sanchez", 5.6));
		alumnos.add(new Alumno(5, "Laura", "Gomez", 7.3));
		alumnos.add(new Alumno(6, "Antonio", "Lara", 8.2));
		
		for (Alumno alumno : alumnos) {
			System.out.println(alumno);
		}
		System.out.println("-------------------");
		
		Set<Alumno> alumnosApellido = new TreeSet<Alumno>(new ApellidoComparator());
		alumnosApellido.add(new Alumno(1, "Juan", "Perez", 7.3));
		alumnosApellido.add(new Alumno(2, "Pedro", "Arias", 4.8));
		alumnosApellido.add(new Alumno(3, "Maria", "Rodriguez", 6.9));
		alumnosApellido.add(new Alumno(4, "Luis", "Sanchez", 5.6));
		alumnosApellido.add(new Alumno(5, "Laura", "Gomez", 7.3));
		alumnosApellido.add(new Alumno(6, "Antonio", "Lara", 8.2));
		
		for (Alumno alumno : alumnosApellido) {
			System.out.println(alumno);
		}
		System.out.println("-------------------");
		
	}

}
