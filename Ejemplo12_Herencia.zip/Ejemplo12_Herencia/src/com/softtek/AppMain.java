package com.softtek;

import com.softtek.models.Jefe;

public class AppMain {

	public static void main(String[] args) {
		// Crear una instancia de Jefe
		Jefe jefe = new Jefe("Juan", 45, 'H', 38_000, 15_000, "1234-LWW");
		System.out.println(jefe.getNombre());
		System.out.println(jefe.getSueldo());
		System.out.println(jefe.getCoche());
		
		// Cuando mostramos un objeto por consola pordefecto llama al metodo toString()
		System.out.println(jefe);
		System.out.println(jefe.toString());
		
		
		Jefe jefe2 = new Jefe("Juan", 45, 'H', 38_000, 15_000, "1234-LWW");
		Jefe jefe3 = new Jefe("Juan", 45, 'H', 38_000, 15_000, "1234-LWW");
		
		int numero1 = 8;
		int numero2 = 8;
		// El operador de igualdad == funciona con tipos primitivos,
		// porque comprueba el contenido de las variables
		System.out.println("Los numeros son iguales? " +  (numero1 == numero2) );
		
		// En el caso de los objetos esto no funciona,
		// debemos comprobar el contenido del objeto, no de las variables
		System.out.println("Los jefes son iguales? " +  (jefe2 == jefe3) );
		System.out.println("Los jefes son iguales? " +  (jefe2.equals(jefe3)) );
		
		

	}

}
