package com.softtek;

import com.softtek.models.MiClase;

public class OtraSubClase extends MiClase {
	
	public void prueba() {
		// Al estar dentro del mismo paquete si que tengo acceso
		metodoPublic();
		// metodoDefault(); No tengo acceso al estar en otro paquete
		metodoProtected();
	}

}
