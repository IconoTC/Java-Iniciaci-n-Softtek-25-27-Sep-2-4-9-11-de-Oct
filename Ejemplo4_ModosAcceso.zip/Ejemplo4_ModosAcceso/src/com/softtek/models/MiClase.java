package com.softtek.models;

public class MiClase {
	
	public void metodoPublic() {
		System.out.println("Metodo publico");
	}
	
	private void metodoPrivate() {
		System.out.println("Metodo privado");
	}
	
	protected void metodoProtected() {
		System.out.println("Metodo protected");
	}
	
	void metodoDefault() {
		System.out.println("Metodo default");
	}

}
