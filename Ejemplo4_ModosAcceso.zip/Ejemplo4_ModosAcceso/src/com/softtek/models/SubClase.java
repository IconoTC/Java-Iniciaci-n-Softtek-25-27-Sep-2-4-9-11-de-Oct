package com.softtek.models;

public class SubClase extends MiClase {
	
	public void prueba() {
		// Al estar dentro del mismo paquete si que tengo acceso
		metodoPublic();
		metodoDefault();
		metodoProtected();
	}

}
