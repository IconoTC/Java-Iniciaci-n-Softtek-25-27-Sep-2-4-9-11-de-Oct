package com.softtek;

import com.softtek.models.MiClase;
import com.softtek.models.SubClase;

public class AppMain {

	public static void main(String[] args) {
		
		MiClase miClase = new MiClase();
		
		// Desde clases de otros paquetes solo puedo acceder a recursos publicos
		miClase.metodoPublic();
		
		
		SubClase subClase = new SubClase();
		subClase.prueba();
		
		
		OtraSubClase otraSubClase = new OtraSubClase();
		otraSubClase.prueba();

	}

}
