package com.softtek;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import com.softtek.models.Producto;
import com.softtek.utils.ComparadorId;

public class AppMain {

	public static void main(String[] args) {
		
		Set<Producto> porId = new TreeSet<Producto>(new ComparadorId());
		porId.add(new Producto(3, "Impresora", 89.95));
		porId.add(new Producto(1, "Teclado", 27.50));
		porId.add(new Producto(5, "Raton", 18));
		porId.add(new Producto(2, "Monitor", 129.75));
		porId.add(new Producto(4, "Scanner", 140));
		
		for (Producto producto : porId) {
			System.out.println(producto);
		}
		System.out.println("-----------------------");
		
		Set<Producto> porDescripcion = new TreeSet<Producto>(new Comparator<Producto>() {

			@Override
			public int compare(Producto p1, Producto p2) {
				return p1.getDescripcion().compareTo(p2.getDescripcion());
			}		
		});
		porDescripcion.add(new Producto(3, "Impresora", 89.95));
		porDescripcion.add(new Producto(1, "Teclado", 27.50));
		porDescripcion.add(new Producto(5, "Raton", 18));
		porDescripcion.add(new Producto(2, "Monitor", 129.75));
		porDescripcion.add(new Producto(4, "Scanner", 140));
		
		for (Producto producto : porDescripcion) {
			System.out.println(producto);
		}
		System.out.println("-----------------------");
		
		
		Set<Producto> porPrecio = new TreeSet<Producto>(new Comparator<Producto>() {

			@Override
			public int compare(Producto p1, Producto p2) {
				if( p1.getPrecio() > p2.getPrecio() ) {
					return 1;
				} else if( p1.getPrecio() < p2.getPrecio() ) {
					return -1;
				} else {
					return 0;
				}
			}
		});
		porPrecio.add(new Producto(3, "Impresora", 89.95));
		porPrecio.add(new Producto(1, "Teclado", 27.50));
		porPrecio.add(new Producto(5, "Raton", 18));
		porPrecio.add(new Producto(2, "Monitor", 129.75));
		porPrecio.add(new Producto(4, "Scanner", 140));
		
		for (Producto producto : porPrecio) {
			System.out.println(producto);
		}
		System.out.println("-----------------------");

	}

}
