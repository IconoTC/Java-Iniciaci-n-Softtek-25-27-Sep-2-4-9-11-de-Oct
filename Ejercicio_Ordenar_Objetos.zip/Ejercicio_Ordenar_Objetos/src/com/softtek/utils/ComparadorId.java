package com.softtek.utils;

import java.util.Comparator;

import com.softtek.models.Producto;

public class ComparadorId implements Comparator<Producto>{

	@Override
	public int compare(Producto p1, Producto p2) {
		return p1.getId() - p2.getId();
	}

}
