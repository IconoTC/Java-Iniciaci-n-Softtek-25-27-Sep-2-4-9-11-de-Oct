package com.softtek.models;

public class Avion extends Vehiculo implements ObjetoVolador{
	
	public Avion() {
		// TODO Auto-generated constructor stub
	}
	
	public Avion(String combustible, int numPasajeros) {
		super(combustible, numPasajeros);
	}

	@Override
	public void despegar() {
		System.out.println("El avion esta despegando");
	}

	@Override
	public void aterrizar() {
		System.out.println("El avion esta aterrizando");
	}

	@Override
	public void volar() {
		System.out.println("El avion esta volando");
	}

}
