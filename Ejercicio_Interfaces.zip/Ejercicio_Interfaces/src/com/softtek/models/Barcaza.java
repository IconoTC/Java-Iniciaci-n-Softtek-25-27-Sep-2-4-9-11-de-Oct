package com.softtek.models;

public class Barcaza extends Vehiculo implements Nautico {

	private int metros;

	public Barcaza() {
		// TODO Auto-generated constructor stub
	}

	public Barcaza(String combustible, int numPasajeros, int metros) {
		super(combustible, numPasajeros);
		this.metros = metros;
	}

	@Override
	public void atracar() {
		System.out.println("La barcaza esta atracando");
	}

	@Override
	public void navegar() {
		System.out.println("La barcaza esta navegando");
	}

	public int getMetros() {
		return metros;
	}

	public void setMetros(int metros) {
		this.metros = metros;
	}

	@Override
	public String toString() {
		return "Barcaza [metros=" + metros + ", toString()=" + super.toString() + "]";
	}
	
	

}
