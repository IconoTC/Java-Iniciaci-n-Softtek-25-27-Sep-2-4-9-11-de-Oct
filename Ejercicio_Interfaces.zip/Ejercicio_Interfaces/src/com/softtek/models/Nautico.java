package com.softtek.models;

public interface Nautico {
	
	void atracar();
	void navegar();

}
