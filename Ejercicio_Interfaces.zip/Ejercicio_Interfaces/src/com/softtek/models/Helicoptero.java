package com.softtek.models;

public class Helicoptero extends Avion{
	
	public Helicoptero() {
		super();
	}
	
	public Helicoptero(String combustible, int numPasajeros) {
		super(combustible, numPasajeros);
	}

}
