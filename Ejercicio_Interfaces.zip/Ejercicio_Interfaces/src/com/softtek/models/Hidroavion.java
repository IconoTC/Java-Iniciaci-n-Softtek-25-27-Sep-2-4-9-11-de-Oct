package com.softtek.models;

public class Hidroavion extends Avion implements Nautico {

	private String nombre;

	public Hidroavion() {
		// TODO Auto-generated constructor stub
	}

	public Hidroavion(String combustible, int numPasajeros, String nombre) {
		super(combustible, numPasajeros);
		this.nombre = nombre;
	}

	@Override
	public void atracar() {
		System.out.println("El hidroavion esta atracando");
	}

	@Override
	public void navegar() {
		System.out.println("El hidroavion esta navegando");
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Hidroavion [nombre=" + nombre + ", toString()=" + super.toString() + "]";
	}
	
	

}
