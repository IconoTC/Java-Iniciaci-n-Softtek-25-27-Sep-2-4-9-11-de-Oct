package com.softtek.models;

public class Vehiculo {
	
	private String combustible;
	private int numPasajeros;
	
	public Vehiculo() {
		// TODO Auto-generated constructor stub
	}

	public Vehiculo(String combustible, int numPasajeros) {
		super();
		this.combustible = combustible;
		this.numPasajeros = numPasajeros;
	}

	public String getCombustible() {
		return combustible;
	}

	public void setCombustible(String combustible) {
		this.combustible = combustible;
	}

	public int getNumPasajeros() {
		return numPasajeros;
	}

	public void setNumPasajeros(int numPasajeros) {
		this.numPasajeros = numPasajeros;
	}

	@Override
	public String toString() {
		return "Vehiculo [combustible=" + combustible + ", numPasajeros=" + numPasajeros + "]";
	}

}
