package com.softtek.models;

public interface ObjetoVolador {
	
	void despegar();
	void aterrizar();
	void volar();

}
