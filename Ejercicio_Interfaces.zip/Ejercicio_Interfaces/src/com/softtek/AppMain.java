package com.softtek;

import com.softtek.models.Barcaza;
import com.softtek.models.Helicoptero;

public class AppMain {

	public static void main(String[] args) {
		// Crear instancia de Helicoptero y Barcaza
		
		Helicoptero helicoptero = new Helicoptero("Queroseno", 5);
		Barcaza barcaza = new Barcaza("Diesel", 20, 80);
		
		System.out.println(helicoptero);
		System.out.println(barcaza);
		
		helicoptero.despegar();
		helicoptero.volar();
		helicoptero.aterrizar();
		System.out.println("Cuantos pasajeros: " + helicoptero.getNumPasajeros());

	}

}
