// nombre del paquete en minusculas
package com.softtek;

// nombre de la clase empieza por mayuscula
public class Saludo {

	// Este metodo marca la clase como principal
	// sera la puerta de entrada a la aplicacion
	// main + ctrl + space
	public static void main(String[] args) {
		
		// Variables y metodos empiezan en minusculas
		
		// syso + ctrl + space
		System.out.println("Bienvenidos al curso de Java");
	}

}
