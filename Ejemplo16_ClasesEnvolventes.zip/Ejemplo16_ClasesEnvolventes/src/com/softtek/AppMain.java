package com.softtek;

public class AppMain {

	public static void main(String[] args) {
		
		int numero = 8;
		
		// Convertir primitivo a un objeto Integer
		// primitivo -> objeto   (Boxing)
		Integer objInteger = Integer.valueOf(numero);
		Integer objInteger2 = new Integer(numero);
	
		
		// Convertir de objeto a tipo primitivo
		// objeto -> primitivo   (UnBoxing)
		numero = objInteger.intValue();
		
		
		// A partir de Java 5 podemos utilizar AutoBoxing
		Integer num = 6;
		int primitiva = objInteger;
		
		
		// Ejemplos de metodos en clases envolventes
		System.out.println("Maximo entre 8 y 5: " + Integer.max(8, 5));
		System.out.println("H es una letra? " + Character.isLetter('H'));
		System.out.println("H es un numero? " + Character.isDigit('H'));
		System.out.println("182 en hexadecimal: " + Integer.toHexString(182));
		System.out.println("182 en octal: " + Integer.toOctalString(182));
		System.out.println("182 en binario: " + Integer.toBinaryString(182));

	}

}
