package com.softtek;

import com.softtek.business.Calculadora;
import com.softtek.util.DivisorException;

public class Principal {

	public static void main(String[] args) {
		
		// Sumar todos los numeros recibidos como argumento
		int suma = 0;
		
		for(String dato : args) {
			
			int numero = 0;
			
			try {
				// sentencias que podrian provocar un error
				numero = Integer.parseInt(dato);
			} catch (NumberFormatException ex) {
				System.out.println("Se produjo un error " + ex.getMessage());
			} catch (NullPointerException | ArithmeticException ex) {
				ex.printStackTrace();
			} catch(Exception ex) {
				// Solo se ejecutara si se ha producido un error
				System.out.println(ex.getMessage());
				ex.printStackTrace();
			} finally {
				// Se ejecuta siempre, haya o no excepciones
				suma += numero;
			}
			
			
		}
		
		System.out.println("Suma: " + suma);
		
		
		
		// Instancia de calculadora
		Calculadora calcu = new Calculadora();
		System.out.println("7 + 5 = " + calcu.sumar(7, 5));
		System.out.println("7 - 5 = " + calcu.restar(7, 5));
		System.out.println("7 * 5 = " + calcu.multiplicar(7, 5));
		try {
			System.out.println("7 / 0 = " + calcu.dividir(7, 0));
		} catch (DivisorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		// Unchecked exception
		System.out.println("7 / 0 = " + calcu.dividir(7, 0));
	}	

}








