package com.softtek.util;

// Hay 2 tipos de excepciones:
//    - checked exception; son las que heredan de Exception y estamos obligados a manejarlas
//    - unchecked excepcion; son las que heredan de RuntimeException y no estamos obligados

public class DivisorException extends RuntimeException{
	
	public DivisorException(String mensaje) {
		super(mensaje);
	}

}
