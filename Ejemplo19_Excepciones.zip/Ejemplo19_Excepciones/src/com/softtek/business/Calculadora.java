package com.softtek.business;

import com.softtek.util.DivisorException;

public class Calculadora {  
	
	public double sumar(int num1, int num2) {
		return num1 + num2;
	}
	
	public double restar(int num1, int num2) {
		return num1 - num2;
	}
	
	public double multiplicar(int num1, int num2) {
		return num1 * num2;
	}
	
	public double dividir(int num1, int num2) throws DivisorException {
		
		if (num2 == 0) {
			// lanzar una excepcion
			throw new DivisorException("No se puede dividir por 0");
		}
		
		return num1 / num2;
	}

}
