package com.softtek;

import java.util.Scanner;

public class Notas {

	public static void main(String[] args) {
		// solicitar nota de 0 a 10 (numero entero)
		// Mostrar suspenso, aprobado, bien, notable, sobresaliente
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce nota del 0 al 10: ");
		int nota = sc.nextInt();
		
		switch (nota) {
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
				System.out.println("Suspenso");
				break;
	
			case 5:
				System.out.println("Aprobado");
				break;
	
			case 6:
				System.out.println("Bien");
				break;
	
			case 7:
			case 8:
				System.out.println("Notable");
				break;
	
			case 9:
			case 10:
				System.out.println("Sobresaliente");
				break;
	
			default:
				System.out.println("Nota no valida");
				break;
		}

	}

}
