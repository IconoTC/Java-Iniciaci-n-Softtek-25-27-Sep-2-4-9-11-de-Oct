package com.softtek;

import java.util.Scanner;

public class EstadoCivil {

	public static void main(String[] args) {
		// solicitar letra al usuario para adivinar su estado civil
		// puede ser mayuscula o minuscula s o S
		// soltero, casado, viudo, divorciado, pareja_hecho
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce estado civil (S,C,V,D,P): ");
		char estado = sc.next().charAt(0);
		
		switch (estado) {
			case 's':
			case 'S':
				System.out.println("Soltero");
				break;
	
			case 'c':
			case 'C':
				System.out.println("Casado");
				break;
	
			case 'v':
			case 'V':
				System.out.println("Viudo");
				break;
	
			case 'd':
			case 'D':
				System.out.println("Divorciado");
				break;
	
			case 'p':
			case 'P':
				System.out.println("Pareja de hecho");
				break;
	
			default:
				System.out.println("Estado civil desconocido");
				break;
		}
		
	}

}
