package com.softtek;

public class AppMain {

	public static void main(String[] args) {
		// Tipos primitivos:
		
		/*
			1.- Numericos enteros:
			byte; 8 bits 01001100  -128 a 127
			short; 16 bits
			int; 32 bits  (defecto)
			long; 64 bits. Hay que poner un sufijo l ó L
		*/
		
		// tipo_dato variable = valor;
		byte numByte = (byte)100;
		short numShort = (short)10_000;
		int numInt = 765666544;
		long numLong = 6557767554222L;
		
		/*
			2.- Numericos reales:
			float; 32 bits. Hay que poner un sufijo f ó F
			double; 64 bits (defecto)
		 */
		
		float numFloat = 3.14F;
		double numDouble = 3.14;
		
		/*
		 	3.- Booleano
		 	boolean; solo admite true o false. Sin comillas
		 */
		boolean pagado = true;
		
		/*
	 		4.- Caracteres
	 		char; 16 bits. Admite un solo caracter entre comillas 'simples'
		 */
		char diaSemana = 'L';
		char euro = '€';
		char tabulador = '\t';
		char phi = '\u03A6';
		
		// La clase String permite almacenar texto sin limite. Va entre comillas "dobles"
		// En Java las clases, sirven como tipo de dato
		String nombre = "Anabel";
		String mensaje = "Hola, que tal?";
		
		// Mostrar la letra phi en consola,
		System.out.println("Letra phi: " + phi);
		
		// Mostrar el mensaje
		System.out.println(mensaje);
	}

}
