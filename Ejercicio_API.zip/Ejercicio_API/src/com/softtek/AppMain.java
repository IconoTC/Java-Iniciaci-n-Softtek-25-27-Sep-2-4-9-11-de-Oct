package com.softtek;

public class AppMain {

	public static void main(String[] args) {
		
		String texto = "Bienvenidos al curso de Java";
		
		// Mostrar la cadena toda en mayusculas
		System.out.println(texto.toUpperCase());
		
		// Mostrar toda la cadena en minusculas
		System.out.println(texto.toLowerCase());
		
		// Mostrar solo la palabra Bienvenidos
		System.out.println(texto.substring(0, texto.indexOf(" ")) + "-----");
		System.out.println(texto.substring(0, "Bienvenidos".length()) + "-----");
		
		// Mostrar solo la palabra Java
		System.out.println(texto.substring(texto.indexOf("J")));
		
		// Mostrar solo la palabra curso
		System.out.println(texto.substring(texto.indexOf("c"), 
				texto.indexOf(" ", texto.indexOf("c"))));
		
		// Mostrar la posicion de la letra c
		System.out.println(texto.indexOf("c"));
		
		// Devolver la longitud de la cadena
		System.out.println(texto.length());
		
		// Modificar las e minusculas por E mayúsculas
		System.out.println(texto.replaceAll("e", "E"));
		
		// Concatenar la frase anterior con "con fecha 14 de Septiembre"
		System.out.println(texto.concat("con fecha 14 de Septiembre"));
		System.out.println(texto +  "con fecha 14 de Septiembre");

	}

}
