package com.softtek.models;

public class Producto {
	
	// Variables de instancia
	// Cada instancia mantiene una copia de estas propiedades
	private int id;
	private String descripcion;
	private double precio;
	
	
	// Variable de clase
	// Solo existe una copia y reside en la clase
	private static int contador;
	
	// Inicializador estatico
	static {
		contador = 0;
	}
	
	public Producto() {
		contador++;
	}

	public Producto(int id, String descripcion, double precio) {
		super();
		this.id = id;
		this.descripcion = descripcion;
		this.precio = precio;
		
		contador++;
	}
	
	// Metodo estatico
	// Clase.metodo()
	public static int getContador() {
		return contador;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Producto [id=" + id + ", descripcion=" + descripcion + ", precio=" + precio + "]";
	}

}
