package com.softtek;

import com.softtek.models.Producto;

public class AppMain {

	public static void main(String[] args) {
		
		Producto producto1 = new Producto(1, "Pantalla", 129.95);
		System.out.println("Contador: " + producto1.getContador());
		
		Producto producto2 = new Producto(2, "Teclado", 35);
		System.out.println("Contador: " + producto2.getContador());
		
		// Es mas correcto llamar a los metodos estaticos a través de la clase
		System.out.println("Contador: " + Producto.getContador());
		
		// Se puede acceder a los recursos estaticos sin 
		// necesidad de crear previamente un objeto
	}

}
