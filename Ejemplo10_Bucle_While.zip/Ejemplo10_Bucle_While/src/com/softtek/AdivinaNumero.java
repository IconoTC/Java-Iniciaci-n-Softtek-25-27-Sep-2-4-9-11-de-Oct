package com.softtek;

import java.util.Scanner;

public class AdivinaNumero {

	public static void main(String[] args) {
		
		// Generar un numero del 1 al 10
		int numero = (int)(Math.random() * 10) + 1;
		
		// solicitar numero para adiviarlo
		// hay que dar pista
		Scanner sc = new Scanner(System.in);
		int prueba = 0;
		
		do {
			System.out.println("Introduce numero del 1 al 10: ");
			prueba = sc.nextInt();
			
			if (prueba < numero) {
				System.out.println("Te has quedado corto, prueba con un numero mayor");
			} else if (prueba > numero) {
				System.out.println("Te has pasado, prueba con un numero menor");
			}
			
		} while (prueba != numero);
		
		System.out.println("Enhorabuena era el numero " + numero);

	}

}
