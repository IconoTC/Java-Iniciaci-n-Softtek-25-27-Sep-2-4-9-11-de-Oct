package com.softtek;

import java.util.Scanner;

public class SolicitarPW {

	public static void main(String[] args) {
		
		// Solicitar la pw al usuario hasta que adivine que es 'curso'
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce pw: ");
		String pw = sc.next();
		
		while (!"curso".equals(pw)) {
			System.out.println("Pw incorrecta, introduce de nuevo: ");
			pw = sc.next();
		}
		
		System.out.println("Enhorabuena, acertaste");

	}

}
