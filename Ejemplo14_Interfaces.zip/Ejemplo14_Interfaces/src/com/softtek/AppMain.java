package com.softtek;

import com.softtek.models.Perro;

public class AppMain {

	public static void main(String[] args) {
		
		Perro perro = new Perro("Fifi", true, 2, 1, 299.90, "Caniche", true);
		System.out.println(perro);

	}

}
