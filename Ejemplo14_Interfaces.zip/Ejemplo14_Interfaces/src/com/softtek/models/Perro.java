package com.softtek.models;

public class Perro extends Animal implements ProductoVenta {

	private int codigo;
	private double precio;

	private String raza;
	private boolean vacunado;

	public Perro() {
		// TODO Auto-generated constructor stub
	}

	public Perro(String nombre, boolean domestico, int edad, int codigo, double precio, String raza, boolean vacunado) {
		super(nombre, domestico, edad);
		this.codigo = codigo;
		this.precio = precio;
		this.raza = raza;
		this.vacunado = vacunado;
	}

	@Override
	public int getCodigo() {
		// TODO Auto-generated method stub
		return codigo;
	}

	@Override
	public void setCodigo(int codigo) {
		// TODO Auto-generated method stub
		this.codigo = codigo;
	}

	@Override
	public double getPrecio() {
		// TODO Auto-generated method stub
		return precio;
	}

	@Override
	public void setPrecio(double precio) {
		// TODO Auto-generated method stub
		this.precio = precio;
	}

	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}

	public boolean isVacunado() {
		return vacunado;
	}

	public void setVacunado(boolean vacunado) {
		this.vacunado = vacunado;
	}

	@Override
	public String toString() {
		return "Perro [codigo=" + codigo + ", precio=" + precio + ", raza=" + raza + ", vacunado=" + vacunado
				+ ", toString()=" + super.toString() + "]";
	}
	
	

}
