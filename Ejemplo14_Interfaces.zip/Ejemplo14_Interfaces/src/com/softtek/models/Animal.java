package com.softtek.models;

public class Animal {
	
	private String nombre;
	private boolean domestico;
	private int edad;
	
	public Animal() {
		// TODO Auto-generated constructor stub
	}

	public Animal(String nombre, boolean domestico, int edad) {
		super();
		this.nombre = nombre;
		this.domestico = domestico;
		this.edad = edad;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public boolean isDomestico() {
		return domestico;
	}

	public void setDomestico(boolean domestico) {
		this.domestico = domestico;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	@Override
	public String toString() {
		return "Animal [nombre=" + nombre + ", domestico=" + domestico + ", edad=" + edad + "]";
	}
	

}
