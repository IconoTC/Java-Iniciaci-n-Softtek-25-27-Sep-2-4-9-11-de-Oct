package com.softtek;

import com.softtek.models.Empleado;
import com.softtek.models.Jefe;
import com.softtek.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		
		// Aplicar polimorfismo
		Object objeto = new Jefe("Juan", 45, 'H', 38_000, 15_000, "1234-LWW");
		Persona persona = new Jefe("Juan", 45, 'H', 38_000, 15_000, "1234-LWW");
		Empleado empleado = new Jefe("Juan", 45, 'H', 38_000, 15_000, "1234-LWW");
		Jefe jefe = new Jefe("Juan", 45, 'H', 38_000, 15_000, "1234-LWW");
		

		// El polimorfismo me permite ver el objeto de multiples formas
		// Que puedo ver? A que recursos tengo acceso
		// Solo veo los recursos declarados en la clase Object
		objeto.getClass();
		
		// Solo veo los recursos declarados en la clase Object y Persona
		persona.getClass();
		persona.getEdad();
		
		// Solo veo los recursos declarados en la clase Object, Persona y Empleado
		empleado.getClass();
		empleado.getEdad();
		empleado.getSueldo();
		
		// Tengo visibilidad total
		// veo los recursos declarados en la clase Object, Persona, Empleado y Jefe
		jefe.getClass();
		jefe.getEdad();
		jefe.getSueldo();
		jefe.getCoche();
		
		// Cambiar la visibilidad del objeto
		// El tipo de la variable es quien limita la visibiliad
		// SOLUCION: guardar el objeto en una variable de otro tipo
		Jefe objetoJefe =  (Jefe) objeto;
		Empleado objetoEmpleado = (Empleado) objeto;
		
		// Otra forma 
		( (Jefe)objeto ).getCoche();
		
		// Esto da error -> ClassCastException
		Persona maria = new Persona("Maria", 35, 'M');
		Jefe jefaMaria = (Jefe) maria;
		
	}

}
