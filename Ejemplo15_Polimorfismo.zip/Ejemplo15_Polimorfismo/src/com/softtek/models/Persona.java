package com.softtek.models;

import java.util.Objects;

// Si la clase no hereda de ninguna, el constructor añade extends Object
// public class Persona extends Object{
public class Persona {
	
	private String nombre;
	private int edad;
	private char sexo;
	
	public Persona() {
		// TODO Auto-generated constructor stub
	}

	public Persona(String nombre, int edad, char sexo) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.sexo = sexo;
	}
	
	@Override
	public String toString() {
		return "nombre=" + nombre + " edad=" + edad + " sexo=" + sexo + " ";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(edad, nombre, sexo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		// Cambiamos la visibilidad a Persona, para que se vean las propiedades
		Persona other = (Persona) obj;
		return edad == other.edad && Objects.equals(nombre, other.nombre) && sexo == other.sexo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}
	

}
