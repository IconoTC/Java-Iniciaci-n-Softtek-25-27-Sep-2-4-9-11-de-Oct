package com.softtek;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		// Set -> No permiten duplicados, No garantiza el orden de entrada
		// List -> Si permite duplicados, SI garantiza el orden de entrada
		
		Set conjunto = new HashSet();
		conjunto.add(4);
		conjunto.add(3.14);
		conjunto.add("Hola");
		conjunto.add(true);
		conjunto.add('A');
		conjunto.add("Hola"); // Los elementos repetidos los ignora
		
		System.out.println(conjunto);
		
		// Recorrer la coleccion con for-each
		for (Object item : conjunto) {
			System.out.println(item);
		}
		
		// Otra forma de recorrer con iterador
		for (Iterator it = conjunto.iterator(); it.hasNext(); ) {
			Object obj = it.next();
			System.out.println(obj);
		}
		
		Iterator it = conjunto.iterator();
		while(it.hasNext()) {
			Object obj = it.next();
			System.out.println(obj);
		}
		
		
		List lista = new ArrayList();
		lista.add(4);
		lista.add(3.14);
		lista.add("Hola");
		lista.add(true);
		lista.add('A');
		lista.add("Hola");
		
		System.out.println(lista);
		
		
		// Recorrer con iterador
		it = lista.listIterator();
		while(it.hasNext()) {
			Object obj = it.next();
			System.out.println(obj);
		}
		
		// Metodos del api Collections
		// add -> agrega un elemento a la coleccion
		
		// remove -> borrar elementos
		lista.remove(5); // Borrar por posicion
		System.out.println(lista);
		
		lista.remove("Hola");  // Borrar por elemento
		System.out.println(lista);

		// size -> devuelve el tamaño de la coleccion (numero de elementos)
		System.out.println("Conjunto: " + conjunto.size());
		System.out.println("Lista: " + lista.size());
		
		// isEmpty -> nos dice si la coleccion esta vacia
		System.out.println("Lista vacia? " + lista.isEmpty());
		
		// contains -> nos dice si contiene un determinado elemento
		System.out.println(lista.contains('A'));
		
		
		
		
		// Map; no se considera coleccion porque no hereda de Collections
		// los elementos se forman key-value
		// las claves (keys) no se pueden repetir
		// pero los value si
		// Tampoco se garantiza el orden de entrada
		Map mapa = new HashMap();
		mapa.put(1, "Hola");
		mapa.put(true, "Adios");
		mapa.put('A', lista);
		mapa.put(true, "Hola");  // Si repito la clave, se sobreescribe el valor
		
		System.out.println(mapa);
		
		// Recuperar un elemento por su clave
		System.out.println(mapa.get('A'));
		
		// entrySet -> retorna una coleccion de tipo Set con todos los elementos key=value
		System.out.println(mapa.entrySet());
		
		// keySet -> retorna una coleccion de tipo Set con todas las claves
		System.out.println(mapa.keySet());
		
		// values -> retorna una coleccion con los values
		System.out.println(mapa.values());
		

	}

}
