package com.softtek;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Genericos {

	public static void main(String[] args) {
		
		// El tipo generico siempre tiene que ser una clase,
		// no se aceptan tipos primitivos
		// Son nuevos en la version 5
		//Set<String> nombres = new HashSet<String>();
		
		// A partir de Java 7
		Set<String> nombres = new HashSet<>();
		
		// nombres.add(4);  // Error de compilacion
		nombres.add("Juan");
		nombres.add("Pedro");
		nombres.add("Luis");
		nombres.add("Maria");
		nombres.add("Laura"); // Los elementos repetidos los ignora
		
		System.out.println(nombres);
		
		// Recorrer la coleccion con for-each
		for (String item : nombres) {
			System.out.println(item.toUpperCase());
		}
		
		// Otra forma de recorrer con iterador
		for (Iterator<String> it = nombres.iterator(); it.hasNext(); ) {
			String obj = it.next();
			System.out.println(obj);
		}
		
		Iterator<String> it = nombres.iterator();
		while(it.hasNext()) {
			String obj = it.next();
			System.out.println(obj);
		}
		
		
		List<Integer> numeros = new ArrayList<>();
		numeros.add(4);
		numeros.add(3);
		numeros.add(new Integer(5));
		numeros.add(28);
		numeros.add(300);
		numeros.add(5700);
		
		System.out.println(numeros);
		
		
		// Recorrer con iterador
		Iterator<Integer> itNum = numeros.listIterator();
		while(itNum.hasNext()) {
			Integer obj = itNum.next();
			System.out.println(obj);
		}
		
		// Metodos del api Collections
		// add -> agrega un elemento a la coleccion
		
		// remove -> borrar elementos
		numeros.remove(5); // Borrar por posicion
		System.out.println(numeros);
		
		numeros.remove(new Integer(300));  // Borrar por elemento
		System.out.println(numeros);

		// size -> devuelve el tamaño de la coleccion (numero de elementos)
		System.out.println("Conjunto: " + nombres.size());
		System.out.println("Lista: " + numeros.size());
		
		// isEmpty -> nos dice si la coleccion esta vacia
		System.out.println("Lista vacia? " + numeros.isEmpty());
		
		// contains -> nos dice si contiene un determinado elemento
		System.out.println(numeros.contains(4));
		
		
		

		Map<String, Double> notas = new HashMap<>();
		notas.put("Matematicas", 5.7);
		notas.put("Ingles", 8.3);
		notas.put("Lengua", 6.9);
		notas.put("Fisica", 7.5);  
		System.out.println(notas);
		
		// Recuperar un elemento por su clave
		System.out.println(notas.get("Ingles"));
		
		// entrySet -> retorna una coleccion de tipo Set con todos los elementos key=value
		System.out.println(notas.entrySet());
		
		// keySet -> retorna una coleccion de tipo Set con todas las claves
		System.out.println(notas.keySet());
		
		// values -> retorna una coleccion con los values
		System.out.println(notas.values());
		

	}

}
