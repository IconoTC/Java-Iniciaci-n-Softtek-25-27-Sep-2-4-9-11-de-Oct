package com.softtek.business;

public interface ItfzMetodos {
	
	// Hasta Java 7 en las interfaces todos los metodos
	// declarados eran publicos y abstractos
	
	// Como novedad en Java 8 podemos incluir:
	//   - Metodos estaticos
	//   - Metodos default
	
	
	public static void estatico() {
		System.out.println("Metodo estatico");
	}
	
	public default void defecto() {
		System.out.println("Metodo default");
	}

}
