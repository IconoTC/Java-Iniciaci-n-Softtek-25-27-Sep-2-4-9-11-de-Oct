package com.softtek;

import com.softtek.business.ItfzMetodos;

public class AppMain {

	public static void main(String[] args) {
		
		// Invocar al metodo estatico
		ItfzMetodos.estatico();
		
		// Invocar al metodo default
		new ItfzMetodos() {
			// No hay metodos abstractos que implementar
		}.defecto();

	}

}
