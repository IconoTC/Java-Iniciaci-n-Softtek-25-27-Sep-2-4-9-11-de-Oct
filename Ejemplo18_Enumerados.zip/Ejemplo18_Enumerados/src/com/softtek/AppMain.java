package com.softtek;

import com.softtek.models.EstadoCivil;
import com.softtek.models.Persona;
import com.softtek.models.PuntoCardinal;

public class AppMain {

	public static void main(String[] args) {
		
		Persona maria = new Persona("Maria", 47, EstadoCivil.DIVORCIADO);
		Persona juan = new Persona("Juan", 32, EstadoCivil.SOLTERO);
		
		System.out.println(maria);
		System.out.println(juan);
		
		
		// Crear un punto cardinal
		PuntoCardinal norte = PuntoCardinal.NORTE;
		System.out.println(norte);
		System.out.println(norte.getLetra());
		System.out.println(norte.getNombreIngles());
		
		
		// Ver todos los puntos cardinales
		for(PuntoCardinal punto : PuntoCardinal.values()) {
			System.out.print(punto + " ");
			System.out.print(punto.ordinal() + " ");
			System.out.print(punto.name() + " ");
			System.out.print(punto.getLetra() + " ");
			System.out.println(punto.getNombreIngles());
		}
		
		// Crear el tipo enumerado a través de un String
		PuntoCardinal sur = PuntoCardinal.SUR;
		PuntoCardinal sur2 = PuntoCardinal.valueOf("SUR");
		System.out.println(sur2);

	}

}
