package com.softtek.models;

public enum EstadoCivil {
	
	// Todos los valores se entienden como constantes: static y final
	// Las constantes se escriben en mayusculas
	SOLTERO, CASADO, VIUDO, DIVORCIADO, PAREJA_HECHO;
	

}
