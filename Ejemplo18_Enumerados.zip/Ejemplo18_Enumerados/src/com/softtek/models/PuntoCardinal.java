package com.softtek.models;

public enum PuntoCardinal {
	
	NORTE('N', "North"), 
	SUR('S', "South"), 
	ESTE('E', "East"), 
	OESTE('O', "West");
	
	// Pueden tener propiedades
	private char letra;
	private String nombreIngles;
	
	
	// El constructor de un tipo enumerado DEBE SER PRIVADO
	private PuntoCardinal(char letra, String nombreIngles) {
		this.letra = letra;
		this.nombreIngles = nombreIngles;
	}


	// Metodos
	public char getLetra() {
		return letra;
	}

	public String getNombreIngles() {
		return nombreIngles;
	}

	// Incluso podriamos poner un metodo main()
	
	

}
