package com.softtek;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AppMain {

	public static void main(String[] args) {
		
		Map<String, List<String>> diccionario = new HashMap<String, List<String>>();
		
		diccionario.put("Banco", Arrays.asList("Banco de Sentarse", "Banco entidad financiera", "Banco de peces"));
		diccionario.put("Mono", Arrays.asList("Animal", "Solo uno", "Vestimenta"));
		diccionario.put("Manta", Arrays.asList("Ropa", "Animal"));
		diccionario.put("Cura", Arrays.asList("Sacerdote", "Remedio a una enfermedad"));
		
		System.out.println("Palabras: " + diccionario.keySet());
		
		System.out.println("Significados de Banco: " + diccionario.get("Banco"));
		
		System.out.println(diccionario.values());
		
		System.out.println(diccionario);

	}

}
